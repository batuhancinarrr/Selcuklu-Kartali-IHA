
#include "can.h"

void CAN_Init(void) {
    // CAN başlatma kodu (örnek)
}

void CAN_HandleMessages(void) {
    // Gelen CAN mesajlarını al ve işle
}
