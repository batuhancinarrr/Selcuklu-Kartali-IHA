#include "stm32f1xx.h"

#define LORA_JAMMER_PIN GPIO_PIN_0
#define WIFI_JAMMER_PIN GPIO_PIN_1
#define GSM_JAMMER_PIN  GPIO_PIN_2

void GPIO_Config(void) {
    __HAL_RCC_GPIOA_CLK_ENABLE();
    GPIO_InitTypeDef GPIO_InitStruct = {0};
    GPIO_InitStruct.Pin = LORA_JAMMER_PIN | WIFI_JAMMER_PIN | GSM_JAMMER_PIN;
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
}
