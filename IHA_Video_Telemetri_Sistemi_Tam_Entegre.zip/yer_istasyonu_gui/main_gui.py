import tkinter as tk
from tkinter import ttk
from PIL import Image, ImageTk
import folium
from io import BytesIO
import serial, json, threading
import cv2

telemetri = {"lat": 0, "lon": 0, "alt": 0}

def seri_veri_okuyucu():
    global telemetri
    ser = serial.Serial("COM4", 9600)
    while True:
        try:
            line = ser.readline().decode()
            telemetri = json.loads(line)
        except: continue

def harita_guncelle():
    global telemetri
    harita = folium.Map(location=[telemetri['lat'], telemetri['lon']], zoom_start=17)
    folium.Marker([telemetri['lat'], telemetri['lon']], tooltip="İHA").add_to(harita)
    data = BytesIO()
    harita.save(data, close_file=False)
    return data.getvalue()

def arayuz_baslat():
    root = tk.Tk()
    root.title("İHA Yer İstasyonu")
    label1 = ttk.Label(root, text="CANLI VİDEO")
    label1.pack()

    cap = cv2.VideoCapture("udp://@:5000", cv2.CAP_FFMPEG)

    def video_goster():
        ret, frame = cap.read()
        if ret:
            frame = cv2.resize(frame, (640, 480))
            img = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            img = ImageTk.PhotoImage(Image.fromarray(img))
            panel.configure(image=img)
            panel.image = img
        panel.after(30, video_goster)

    panel = tk.Label(root)
    panel.pack()

    threading.Thread(target=seri_veri_okuyucu, daemon=True).start()
    video_goster()
    root.mainloop()

arayuz_baslat()
