import serial, time, smbus
import pynmea2
import json

gps = serial.Serial("/dev/ttyAMA0", baudrate=9600, timeout=1)
lora = serial.Serial("/dev/serial0", baudrate=9600)
imu = smbus.SMBus(1)

def read_gps():
    while True:
        line = gps.readline().decode('utf-8', errors='ignore')
        if line.startswith('$GPGGA'):
            try:
                msg = pynmea2.parse(line)
                return msg.latitude, msg.longitude, msg.altitude
            except: continue

def read_imu():
    try:
        acc_x = imu.read_word_data(0x68, 0x3B)
        acc_y = imu.read_word_data(0x68, 0x3D)
        acc_z = imu.read_word_data(0x68, 0x3F)
        return acc_x, acc_y, acc_z
    except:
        return 0, 0, 0

while True:
    lat, lon, alt = read_gps()
    acc_x, acc_y, acc_z = read_imu()
    data = {
        "lat": lat,
        "lon": lon,
        "alt": alt,
        "acc_x": acc_x,
        "acc_y": acc_y,
        "acc_z": acc_z
    }
    lora.write((json.dumps(data) + "\n").encode())
    time.sleep(1)
