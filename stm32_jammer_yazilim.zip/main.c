
#include "stm32f1xx.h"
#include "can.h"
#include "rf_control.h"
#include "config.h"

int main(void) {
    HAL_Init();
    SystemClock_Config();
    CAN_Init();
    RF_Control_Init();

    while (1) {
        CAN_HandleMessages();
        RF_Update();
    }
}
