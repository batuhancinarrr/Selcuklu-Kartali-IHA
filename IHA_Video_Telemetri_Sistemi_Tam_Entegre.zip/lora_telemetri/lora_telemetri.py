# LoRa verici örneği
import serial
print('LoRa bağlantısı sağlandı')
