
#ifndef CONFIG_H
#define CONFIG_H

#define PWM_CHANNEL TIM_CHANNEL_1
#define RF_ENABLE_PIN GPIO_PIN_0

#endif
