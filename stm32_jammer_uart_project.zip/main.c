
#include "main.h"
#include <string.h>
#include <stdlib.h>

SPI_HandleTypeDef hspi1;
UART_HandleTypeDef huart1;

char uart_rx_buffer[64];
uint8_t uart_index = 0;
uint8_t uart_command_ready = 0;
char rx_char;
uint8_t sweep_enabled = 0;

uint32_t reg_values[6] = {
    0x00BC8000,  // R0
    0x8008011,   // R1
    0x00004E42,  // R2
    0x0000004B,  // R3
    0x00C80004,  // R4
    0x00580005   // R5
};

void SystemClock_Config(void) {}
void MX_GPIO_Init(void) {}
void MX_SPI1_Init(void) {}
void MX_USART1_UART_Init(void) {}

#define ADF4351_LE_PORT GPIOA
#define ADF4351_LE_PIN  GPIO_PIN_4
#define PA_ENABLE_PORT  GPIOA
#define PA_ENABLE_PIN   GPIO_PIN_1

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
    if (huart->Instance == USART1)
    {
        if (rx_char == '\n' || rx_char == '\r') {
            uart_rx_buffer[uart_index] = '\0';
            uart_command_ready = 1;
            uart_index = 0;
        } else {
            uart_rx_buffer[uart_index++] = rx_char;
            if (uart_index >= sizeof(uart_rx_buffer)) uart_index = 0;
        }
        HAL_UART_Receive_IT(&huart1, (uint8_t *)&rx_char, 1);
    }
}

void PA_Enable() {
    HAL_GPIO_WritePin(PA_ENABLE_PORT, PA_ENABLE_PIN, GPIO_PIN_SET);
}

void PA_Disable() {
    HAL_GPIO_WritePin(PA_ENABLE_PORT, PA_ENABLE_PIN, GPIO_PIN_RESET);
}

void ADF4351_SendRegister(uint32_t reg)
{
    uint8_t bytes[4];
    bytes[0] = (reg >> 24) & 0xFF;
    bytes[1] = (reg >> 16) & 0xFF;
    bytes[2] = (reg >> 8) & 0xFF;
    bytes[3] = reg & 0xFF;

    HAL_GPIO_WritePin(ADF4351_LE_PORT, ADF4351_LE_PIN, GPIO_PIN_RESET);
    HAL_SPI_Transmit(&hspi1, bytes, 4, HAL_MAX_DELAY);
    HAL_GPIO_WritePin(ADF4351_LE_PORT, ADF4351_LE_PIN, GPIO_PIN_SET);
    HAL_Delay(1);
}

void ADF4351_Init()
{
    for (int i = 5; i >= 0; i--) {
        ADF4351_SendRegister(reg_values[i]);
    }
}

void ADF4351_SetFrequency(uint32_t freq_mhz)
{
    // Bu örnekte sadece R0 ve R1 değişiyor, sabit örnekler
    if (freq_mhz == 868) {
        reg_values[0] = 0x00BC8000;
        reg_values[1] = 0x8008011;
    } else if (freq_mhz == 900) {
        reg_values[0] = 0x00C00000;
        reg_values[1] = 0x8008011;
    }
    ADF4351_Init();
}

void Jammer_FrequencySweep()
{
    for (uint32_t f = 868; f <= 915; f++) {
        ADF4351_SetFrequency(f);
        HAL_Delay(50);
    }
}

void Process_UART_Command()
{
    if (strncmp(uart_rx_buffer, "FREQ", 4) == 0) {
        uint32_t freq = atoi(&uart_rx_buffer[5]);
        ADF4351_SetFrequency(freq);
    } else if (strcmp(uart_rx_buffer, "START") == 0) {
        sweep_enabled = 1;
    } else if (strcmp(uart_rx_buffer, "STOP") == 0) {
        sweep_enabled = 0;
    } else if (strcmp(uart_rx_buffer, "PAON") == 0) {
        PA_Enable();
    } else if (strcmp(uart_rx_buffer, "PAOFF") == 0) {
        PA_Disable();
    }
}

int main(void)
{
    HAL_Init();
    SystemClock_Config();
    MX_GPIO_Init();
    MX_SPI1_Init();
    MX_USART1_UART_Init();

    HAL_UART_Receive_IT(&huart1, (uint8_t *)&rx_char, 1);

    PA_Disable();
    ADF4351_SetFrequency(868);
    PA_Enable();

    while (1)
    {
        if (uart_command_ready) {
            uart_command_ready = 0;
            Process_UART_Command();
        }

        if (sweep_enabled) {
            Jammer_FrequencySweep();
        }
    }
}
