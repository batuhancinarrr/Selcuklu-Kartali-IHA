# Yer istasyonu Python GUI (OpenCV + Telemetri)
import cv2
print('GUI başlatılıyor...')
