
import serial
import time

ser = serial.Serial('COM3', 115200)
buffer = bytearray()
filename = f'image_{int(time.time())}.jpg'

while True:
    data = ser.read(1024)
    if data:
        buffer += data
        if len(buffer) > 30000:  # Tahmini jpeg boyutu
            with open(filename, 'wb') as f:
                f.write(buffer)
            print(f'Kaydedildi: {filename}')
            break
